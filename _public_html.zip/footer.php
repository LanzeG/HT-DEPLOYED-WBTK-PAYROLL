<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Add your CSS styles here */
        body {
            margin: 0; /* Remove default body margin */
            padding: 0; /* Remove default body padding */
        }
        @media screen and (min-width: 768px) {
    /* Responsive styles for smaller screens */
   #footer {
    background-color: #333;
    color: #fff;
    text-align: left;
    padding: 10px;
    position: absolute; /* Change to absolute */
    bottom: 0;
    left: 0;
    width: 100%;
}
}

    </style>
</head>
<body>
    <div id="footer" class="span12">2023 &copy; WEB-BASED TIMEKEEPING AND PAYROLL SYSTEM USING FINGERPRINT BIOMETRICS</div>
</body>
</html>
