
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Home</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="../jquery-ui-1.12.1/jquery-ui.css"/>
<link rel="stylesheet" href="../timepicker/jquery.timepicker.css"/>
<script src="../jquery-ui-1.12.1/jquery-3.2.1.js"></script>
<script src="../timepicker/jquery.timepicker.min.js"></script>
<script src="../timepicker/jquery.timepicker.js"></script>
<script type="text/javascript" src="../timepicker/lib/bootstrap-datepicker.js"></script>
  <link rel="stylesheet" type="text/css" href="../timepicker/lib/bootstrap-datepicker.css" />
<script type ="text/javascript">
$( function() {
      $('#shiftStartTime').timepicker({ 'timeFormat': 'H:i:s' });
 } );
</script>

</head>

<body>

<p>
	<input id="shiftStartTime" type="text" class="time">





</body>
</htm